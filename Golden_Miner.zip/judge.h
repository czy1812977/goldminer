#ifndef JUDGE_H
#define JUDGE_H

#endif // JUDGE_H
class judge{
        public:
    static int mode;
};
