#include "stone_1.h"
#include<QPixmap>

stone_1::stone_1()
{
this->setPixmap(QPixmap(":/gameitem/img/mengduo.png"));
}
