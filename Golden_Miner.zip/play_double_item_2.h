#ifndef PLAY_DOUBLE_ITEM_2_H
#define PLAY_DOUBLE_ITEM_2_H
#include<QGraphicsPixmapItem>

class play_double_item_2:public QGraphicsPixmapItem
{
public:
    play_double_item_2();
};

#endif // PLAY_DOUBLE_ITEM_2_H
